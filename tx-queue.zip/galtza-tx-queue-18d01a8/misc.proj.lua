﻿-- Copyright © 2017-2025 Raúl Ramos García. All rights reserved.

project "misc"
    kind  "None"
    files { 
        ".clang-format", 
        ".runcommandonsave", 
        ".gitignore",
        "**/*.lua.",
    }
